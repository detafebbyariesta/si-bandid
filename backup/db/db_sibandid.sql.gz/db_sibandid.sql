CREATE DATABASE IF NOT EXISTS `db_sibandid`;

USE `db_sibandid`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `tb_apbdes`;

CREATE TABLE `tb_apbdes` (
  `id_apbdes` int(11) NOT NULL AUTO_INCREMENT,
  `apbdes` varchar(100) NOT NULL,
  `perdes` varchar(100) NOT NULL,
  `perkades` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_apbdes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_apbdes_perub`;

CREATE TABLE `tb_apbdes_perub` (
  `id_apbdes_perub` int(11) NOT NULL AUTO_INCREMENT,
  `apbdes_perub` varchar(100) NOT NULL,
  `perdes` varchar(100) NOT NULL,
  `perkades` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_apbdes_perub`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_ba_kas`;

CREATE TABLE `tb_ba_kas` (
  `id_ba_kas` int(11) NOT NULL AUTO_INCREMENT,
  `ba_kas` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_ba_kas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_bulanan`;

CREATE TABLE `tb_bulanan` (
  `id_bulanan` int(11) NOT NULL AUTO_INCREMENT,
  `bulanan` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  `bulan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_bulanan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_habis_pakai`;

CREATE TABLE `tb_habis_pakai` (
  `id_habis_pakai` int(11) NOT NULL AUTO_INCREMENT,
  `habis_pakai` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_habis_pakai`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_ippd`;

CREATE TABLE `tb_ippd` (
  `id_ippd` int(11) NOT NULL AUTO_INCREMENT,
  `ippd` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_ippd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_lain`;

CREATE TABLE `tb_lain` (
  `id_lain_lain` int(11) NOT NULL AUTO_INCREMENT,
  `lain_lain` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_lain_lain`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_lkpj`;

CREATE TABLE `tb_lkpj` (
  `id_lkpj` int(11) NOT NULL AUTO_INCREMENT,
  `lkpj` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_lkpj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_lppd`;

CREATE TABLE `tb_lppd` (
  `id_lppd` int(11) NOT NULL AUTO_INCREMENT,
  `lppd` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_lppd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_omspan`;

CREATE TABLE `tb_omspan` (
  `id_omspan` int(11) NOT NULL AUTO_INCREMENT,
  `omspan` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_omspan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_realisasi_add`;

CREATE TABLE `tb_realisasi_add` (
  `id_realisasi_add` int(11) NOT NULL AUTO_INCREMENT,
  `realisasi_add` varchar(100) NOT NULL,
  `foto_add_1` varchar(100) NOT NULL,
  `foto_add_2` varchar(100) NOT NULL,
  `foto_add_3` varchar(100) NOT NULL,
  `foto_add_4` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_realisasi_add`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_realisasi_apbdes`;

CREATE TABLE `tb_realisasi_apbdes` (
  `id_realisasi_apbdes` int(11) NOT NULL AUTO_INCREMENT,
  `realisasi_apbdes` varchar(100) NOT NULL,
  `foto_apbdes_1` varchar(100) NOT NULL,
  `foto_apbdes_2` varchar(100) NOT NULL,
  `foto_apbdes_3` varchar(100) NOT NULL,
  `foto_apbdes_4` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_realisasi_apbdes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_realisasi_apbdes_dana`;

CREATE TABLE `tb_realisasi_apbdes_dana` (
  `id_realisasi_apbdes_dana` int(11) NOT NULL AUTO_INCREMENT,
  `realisasi_apbdes_dana` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_realisasi_apbdes_dana`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_realisasi_dd`;

CREATE TABLE `tb_realisasi_dd` (
  `id_realisasi_dd` int(11) NOT NULL AUTO_INCREMENT,
  `realisasi_dd` varchar(100) NOT NULL,
  `foto_dd_1` varchar(100) NOT NULL,
  `foto_dd_2` varchar(100) NOT NULL,
  `foto_dd_3` varchar(100) NOT NULL,
  `foto_dd_4` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_realisasi_dd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_realisasi_pad`;

CREATE TABLE `tb_realisasi_pad` (
  `id_realisasi_pad` int(11) NOT NULL AUTO_INCREMENT,
  `realisasi_pad` varchar(100) NOT NULL,
  `foto_pad_1` varchar(100) NOT NULL,
  `foto_pad_2` varchar(100) NOT NULL,
  `foto_pad_3` varchar(100) NOT NULL,
  `foto_pad_4` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_realisasi_pad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_rekap_realisasi_apbdes`;

CREATE TABLE `tb_rekap_realisasi_apbdes` (
  `id_rekap_realisasi_apbdes` int(11) NOT NULL AUTO_INCREMENT,
  `rekap_realisasi_apbdes` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_rekap_realisasi_apbdes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_retribusi`;

CREATE TABLE `tb_retribusi` (
  `id_retribusi` int(11) NOT NULL AUTO_INCREMENT,
  `retribusi` varchar(100) NOT NULL,
  `foto1` varchar(100) NOT NULL,
  `foto2` varchar(100) NOT NULL,
  `foto3` varchar(100) NOT NULL,
  `foto4` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_retribusi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_rkpdes`;

CREATE TABLE `tb_rkpdes` (
  `id_rkpdes` int(11) NOT NULL AUTO_INCREMENT,
  `rkpdes` varchar(100) NOT NULL,
  `perdes` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_rkpdes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_rpd`;

CREATE TABLE `tb_rpd` (
  `id_rpd` int(11) NOT NULL AUTO_INCREMENT,
  `rpd` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_rpd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_rpjmdes`;

CREATE TABLE `tb_rpjmdes` (
  `id_rpjmdes` int(11) NOT NULL AUTO_INCREMENT,
  `rpjmdes` varchar(100) NOT NULL,
  `perdes` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_rpjmdes`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_rpjmdes` VALUES (5,"RPJMDes_4312133.xlsx","PERDes_12384033.pdf",2,2021,"Menunggu Validasi","");


DROP TABLE IF EXISTS `tb_sk`;

CREATE TABLE `tb_sk` (
  `id_sk` int(11) NOT NULL AUTO_INCREMENT,
  `sk` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_sk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_smt_1`;

CREATE TABLE `tb_smt_1` (
  `id_smt_1` int(11) NOT NULL AUTO_INCREMENT,
  `smt_1` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_smt_1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_smt_2`;

CREATE TABLE `tb_smt_2` (
  `id_smt_2` int(11) NOT NULL AUTO_INCREMENT,
  `smt_2` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_smt_2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_tanggung_jawab`;

CREATE TABLE `tb_tanggung_jawab` (
  `id_tanggung_jawab` int(11) NOT NULL AUTO_INCREMENT,
  `tanggung_jawab` varchar(100) NOT NULL,
  `perdes` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_tanggung_jawab`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_tutup_kas`;

CREATE TABLE `tb_tutup_kas` (
  `id_tutup_kas` int(11) NOT NULL AUTO_INCREMENT,
  `tutup_kas` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tahun` year(4) NOT NULL,
  `validasi` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_tutup_kas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_user` varchar(50) NOT NULL,
  `level` enum('admin','user') NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_user` VALUES (1,"admin","$2y$10$JGgb2FSaT22Dt99kuI691..pr7WaAl375lac3nAJSOhSK1BDBYi6q","Admin","admin"),
(2,"user","$2y$10$3G9/XDZqKJcOI0o9WDhMP.3wGUJYD3vndfgVI5A8mCNWeCaHehiTC","Mranggen","user");


SET foreign_key_checks = 1;
